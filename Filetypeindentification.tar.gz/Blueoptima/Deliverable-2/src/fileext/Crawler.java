package fileext;
import java.util.Scanner;
import java.util.HashMap;
public class Crawler {
//HashMap to Store Data In (Key,value) Pair
public static HashMap<String,String> Details=new HashMap< String,String>();
private static Scanner rosha; 
   public static synchronized void Insert(String key,String value)
   {
	   Details.put(key,value);
   }
   public static void main(String[] args) 
   { 
       try 
       {  
    	   String Input;
    	   rosha = new Scanner(System.in);
    	   System.out.println("enter your filename as some.txt :-");
    	   Input=rosha.nextLine();
    	   //splitting filename with "."
    	   String[] fileinfo=Input.split(",");
    	   Output o=new Output();
    	   o.my_open();
    	   for(int i=0;i<fileinfo.length;i++)
    	   {
	    	   String  ext[]=fileinfo[i].split("\\.");
	    	   Thread thread1= new Thread(new Fileinfo(ext[1]));
	    	   Thread thread2= new Thread(new FileExtension(ext[1]));
	    	   Thread thread3= new Thread(new Filext(ext[1])); 
	    	   thread1.start();   
	    	   thread2.start();
	    	   thread3.start();
	   	       thread1.join();
	    	   thread2.join();
	    	   thread3.join();
	    	   Thread thread4=new Thread(new Output(ext[1]));
	    	   thread4.start();
	    	   thread4.join();
    	   }
    	   o.my_flush();
       }
      catch (Exception e) 
      {
         e.printStackTrace();
      }
       
   }
}