package fileext;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;

public class Output extends Crawler implements Runnable
{
	String ext="";
	public  static BufferedWriter writer;
	 
	//Null constructor
	public Output(){}
	//constructor to pass extension
	public Output(String string) {
		this.ext=string;
	}

	public void run()
	{
		try
		{
			writer.write("."+ext+" File Extension Info :- \n");
			for (Iterator<Entry<String, String>> iterator = Details.entrySet().iterator(); iterator
					.hasNext();)
			{
				Entry<String, String> m = iterator.next();
				writer.write(m.getKey()+" "+m.getValue()+"\n");
			}   
			writer.write("                                   ------------------------------------------                 \n");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	void my_flush() throws IOException
	{
		try
		{
			writer.flush();
			writer.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	void my_open() throws IOException
	{
		try
		{
			File file = new File("Output.txt");
			writer = new BufferedWriter(new FileWriter(file));
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
