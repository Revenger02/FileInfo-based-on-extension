package fileext;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class Fileinfo extends Crawler implements Runnable
{
	
	String ext="";
	//constructor to pass extension 
	public Fileinfo(String string) {
		this.ext=string;
		
	}
	
	 public void run()
	   {
		   //	Source URL
		   String html = "https://fileinfo.com/extension/"+ext;
		   //	Follow Up Code Will Be Used To Extract Information From Source			
		   try{
			   Document doc = Jsoup.connect(html).get();
			   Elements tableElements=doc.select(".ext");
			   for (Element element : tableElements) 
			   { 	
				   //	count++;
				   String FileType =element.select("h2").first().text();
				   String temp[]=FileType.split(" "); 
				   String filetype=(temp[0]+temp[1]).substring(8)+temp[2].substring(0);
				   for(int i=3;i<temp.length;i++)
					   filetype=filetype+" "+temp[i];
				   Insert((temp[0]+temp[1]).substring(0,8)+"-",filetype);
				   Elements tableHeaderEles = element.select(".headerInfo");
				   Elements table = tableHeaderEles.select("td");
				   
				   for (int i = 0; i < table.size(); i=i+2) 
				   {
					   if(!(table.get(i).text()).equals("Popularity"))
						   Insert(table.get(i).text()+"-",table.get(i+1).text());
				   }	   
			   }
		   }
		   catch(Exception e)
		   {
			   Insert("ERROR-","404 no data avialable at fileinfo");
		   }
	   }
}
